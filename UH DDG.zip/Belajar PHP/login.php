<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    
<for action="handler_login.php" method="post">
    <div>
        <label for="">ID</label>
        <input type="text" name="id">
    </div>
    <div>
        <label for="">Nama</label>
        <input type="text" name="Nama">
    </div>
    <div>
        <label for="">email</label>
        <input type="email" name="email">
    </div>
    <div>
        <label for="">password</label>
        <input type="password" name="password">
    </div>
    
</body>
</html>